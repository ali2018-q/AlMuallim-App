plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace = "com.almualim.feature.settings"; compileSdk = 35; defaultConfig { minSdk = 24 }; buildFeatures { compose = true }; compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }; kotlinOptions { jvmTarget = "17" } }
dependencies { implementation(platform("androidx.compose:compose-bom:2025.02.00")); implementation("androidx.compose.material3:material3"); implementation("androidx.compose.ui:ui") }
