# المعلّم | Al-Muallim

لعبة ثقافية عربية/إنجليزية لأجهزة Android، مبنية باستخدام Kotlin وJetpack Compose، مع Firebase كخلفية سحابية.

> **حالة المستودع:** تأسيس منظم قابل للتطوير. لا تعتبر هذه النسخة إصداراً نهائياً أو لعبة مكتملة. ميزات اللعب والحسابات والترتيب ستنفذ وتختبر على مراحل.

## التقنية

- Android: Kotlin, Jetpack Compose, Material 3
- Backend: Firebase Authentication, Cloud Firestore, Cloud Functions
- Tests: JUnit + Firebase Emulator Suite
- CI: GitHub Actions

## هيكل المستودع

```text
Al-Muallim/
├── app/                    # تطبيق Android
├── core/                   # منطق مشترك ونماذج وقواعد
├── feature/                # ميزات التطبيق حسب المجال
├── functions/              # وظائف Firebase الموثوقة
├── firebase/               # قواعد وفهارس وإعدادات Firebase
├── docs/                   # وثائق التصميم والهندسة والخطة
├── scripts/                # أدوات مساعدة
└── .github/workflows/      # فحوصات وبناء Android
```

## المتطلبات

- Android Studio حديث
- JDK 17
- Android SDK 35
- Node.js 20 أو أحدث لوظائف Firebase
- Firebase CLI عند إعداد المشروع السحابي

## إعداد Android

1. افتح المستودع في Android Studio.
2. أنشئ مشروع Firebase خاصاً بك.
3. سجّل تطبيق Android بالمعرّف `com.almualim.app`.
4. نزّل `google-services.json` وضعه في `app/` عند بدء مرحلة ربط Firebase الفعلية. الملف مستثنى من Git.
5. إضافة Google Services Gradle plugin وتهيئة Firebase في التطبيق ستكون ضمن مرحلة الربط، وليست مفعّلة في هذا الهيكل الأولي.
6. نفّذ Gradle Sync وشغّل التطبيق على محاكي أو جهاز.

## أوامر البناء والاختبار

```bash
./gradlew test
./gradlew assembleDebug
```

الناتج المحلي عند نجاح البناء:
`app/build/outputs/apk/debug/app-debug.apk`

## إعداد Firebase Functions

```bash
cd functions
npm ci
npm test
npm run build
```

بعد إنشاء مشروع Firebase وإعداد صلاحياته:
```bash
firebase use --add
firebase emulators:start
```

لا تنشر قواعد أو وظائف قبل مراجعة إعدادات المشروع واختبارها على Emulator.

## مبادئ الأمان

- لا يكتب تطبيق Android رصيد النقاط أو إجمالي لوحة الترتيب مباشرة.
- احتساب النقاط يجب أن يتم على الخادم بعد التحقق من محاولة المرحلة.
- يجب أن يكون إكمال المرحلة idempotent باستخدام معرف محاولة فريد.
- قواعد Firestore تبدأ بمنع الوصول، ثم تُفتح المسارات الضرورية فقط.
- لا تضع مفاتيح خاصة أو ملفات خدمة Firebase في GitHub.
- `google-services.json` خاص بتهيئة تطبيق Firebase ولا يغني عن قواعد الأمان؛ مع ذلك يُستثنى هنا لتفادي نشر إعدادات مشروعك قبل اختيار سياسة النشر.

## سياسة الأسئلة

- لا تُضاف أسئلة دينية أو عقائدية أو مذهبية أو فقهية.
- لا تُستخدم أسئلة تجريبية على أنها مخزون إنتاجي.
- يجب أن يكون لكل سؤال معرف ثابت، ومجال، ومستوى صعوبة، ونص عربي وإنجليزي، وأربعة خيارات، وإجابة صحيحة موثقة المصدر.
- راجع كل سؤال بشرياً قبل نشره.
- لا تُكرر الفكرة نفسها بمعرّفات مختلفة.

## خارطة الطريق

راجع `docs/ROADMAP.md` و`docs/ARCHITECTURE.md`. لا تُعلن أي مرحلة مكتملة إلا بعد نجاح اختبارات الوحدة والتكامل المطلوبة لها.
